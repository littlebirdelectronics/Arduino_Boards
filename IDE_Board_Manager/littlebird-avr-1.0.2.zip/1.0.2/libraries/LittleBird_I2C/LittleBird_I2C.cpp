/*************************************************** 
This is a library for the LittleBird Standard I2C library

Designed specifically to work with the LittleBird Shakey
----> https://www.littlebirdelectronics.com.au/shakey

  
LittleBird invests time and resources providing this open source code, 
please support LittleBird and open-source hardware by purchasing 
products from LittleBird Electronics!

Written by JP Liew for Little Bird Electronics
BSD license, all text above must be included in any redistribution
****************************************************/

// This is a minimalist library returning just the temperature. 
// There are a other features for LM75A that will be progressively implemented.
 
#include <Wire.h>
#include "LittleBird_I2C.h"

uint8_t _i2cAddress;

LittleBird_I2C::LittleBird_I2C()
{

}

void LittleBird_I2C::begin()
{
	Wire.begin();
}


void LittleBird_I2C::end()
{
	Wire.end();
}

void LittleBird_I2C::setAddress(uint8_t i2cAddress)
{
	_i2cAddress=i2cAddress;
}

uint8_t LittleBird_I2C::getAddress()
{
	return _i2cAddress;
}

uint8_t LittleBird_I2C::readByte(uint8_t regAddr)
{
	uint8_t data;
	readBytes(regAddr, &data, 1);
	return data;
}

uint8_t LittleBird_I2C::readBytes(uint8_t regAddr, uint8_t *data, uint8_t length)
{
	uint8_t count=0;
	
	for (uint8_t i=0; i< length; i += min((int)length, BUFFER_LENGTH)) {
		Wire.beginTransmission(_i2cAddress);
		Wire.write(regAddr);
		Wire.endTransmission();
		Wire.beginTransmission(_i2cAddress);
		Wire.requestFrom(_i2cAddress, (uint8_t)min(length-i, BUFFER_LENGTH));
		
		for(; Wire.available(); count++) {
			data[count]=Wire.read();
		}
	}
	return count;
}

bool LittleBird_I2C::writeByte(uint8_t regAddr, uint8_t data) 
{
	Wire.beginTransmission(_i2cAddress);
	Wire.write(regAddr);
	Wire.write(data);
	Wire.endTransmission();
	return true;
}

bool LittleBird_I2C::writeBytes(uint8_t regAddr, uint8_t *data, uint8_t length)
{
	return true;

}

