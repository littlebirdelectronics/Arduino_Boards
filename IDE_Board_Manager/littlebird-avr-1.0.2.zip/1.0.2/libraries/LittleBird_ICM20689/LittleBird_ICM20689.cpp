/*************************************************** 
This is a library for the LittleBird ICM-20689 MEMS Motion Tracking Device

Designed specifically to work with the LittleBird Shakey
----> https://www.littlebirdelectronics.com.au/shakey


LittleBird invests time and resources providing this open source code, 
please support LittleBird and open-source hardware by purchasing 
products from LittleBird Electronics!

Written by JP Liew for Little Bird Electronics
BSD license, all text above must be included in any redistribution
****************************************************/

// This is a minimalist library returning just the needed features
// There are a other features for ICM20689 that will be progressively implemented.
// IMPORTANT! This library is using DEFAULT setting, FS_SEL=0 , if user changing FS_SEL, need change Sensitivity Scale Factor 131 too.

#include <LittleBird_I2C.h>
#include "LittleBird_ICM20689.h"

#define DEBUG

LittleBird_I2C i2c;
rawdata gyroOffset;
rawdata accelOffset;

LittleBird_ICM20689::LittleBird_ICM20689()
{
	i2c.setAddress(ICM20689_DEFAULT_ADDRESS);
}

LittleBird_ICM20689::LittleBird_ICM20689(uint8_t i2cAddress)
{
	i2c.setAddress(i2cAddress);
}

void LittleBird_ICM20689::begin()
{
	i2c.begin();
	
}

void LittleBird_ICM20689::end()
{
	i2c.end();
}

void LittleBird_ICM20689::init()
{
	setClockSource(3);	// CLKSEL set for best available clock source
	// TODO ?? or leave at DEFAULT
	//setFullScaleGyroRange();
	//setFullScaleAccelRange();
	setSleep(false);	// Wake up
}

uint8_t LittleBird_ICM20689::getAddress()
{
	return i2c.getAddress();
}

uint8_t LittleBird_ICM20689::whoami() 
{
	return i2c.readByte(ICM20689_WHO_AM_I);
}

void LittleBird_ICM20689::calibrate()
{
	uint8_t count=30;		// do not set count to a big number, offsets when added too many times will overflow int6_t datatype
	rawdata raw;

	for (int i=0; i< count;i++) {
		getRAWGyro(&raw);
		gyroOffset.x = gyroOffset.x + raw.x;
		gyroOffset.y = gyroOffset.y + raw.y;
		gyroOffset.z = gyroOffset.z + raw.z;
	}
	
	for (int i=0; i< count;i++) {
		getRAWAccel(&raw);
		accelOffset.x = accelOffset.x + raw.x;
		accelOffset.y = accelOffset.y + raw.y;
		accelOffset.z = accelOffset.z + raw.z;
	}
	
	
	gyroOffset.x = (int16_t)(gyroOffset.x / count);
	gyroOffset.y = (int16_t)(gyroOffset.y / count);
	gyroOffset.z = (int16_t)(gyroOffset.z / count);
	
	accelOffset.x = (int16_t)(accelOffset.x / count);
	accelOffset.y = (int16_t)(accelOffset.y / count);
	accelOffset.z = (int16_t)(accelOffset.z / count);

}

void LittleBird_ICM20689::getRAWGyro(rawdata *raw)
{
	uint8_t buffer[6];
	uint8_t readcount=i2c.readBytes(ICM20689_GYRO_XOUT_H, buffer, (uint8_t)6);
	
	raw->x = buffer[0]<<8 | buffer[1];
	raw->y = buffer[2]<<8 | buffer[3];
	raw->z = buffer[4]<<8 | buffer[5];

}

void LittleBird_ICM20689::getRAWAccel(rawdata *raw)
{
	uint8_t buffer[6];
	uint8_t readcount=i2c.readBytes(ICM20689_ACCEL_XOUT_H, buffer, (uint8_t)6);
	
	raw->x = buffer[0]<<8 | buffer[1];
	raw->y = buffer[2]<<8 | buffer[3];
	raw->z = buffer[4]<<8 | buffer[5];

}

float LittleBird_ICM20689::getGyroX()
{
	uint8_t highbyte = i2c.readByte(ICM20689_GYRO_XOUT_H);
	uint8_t lowbyte  = i2c.readByte(ICM20689_GYRO_XOUT_L);
	int16_t gyro_xout = highbyte <<8 | lowbyte;
	
	return (float)(gyro_xout-gyroOffset.x)/131;
}

float LittleBird_ICM20689::getGyroY()
{
	uint8_t highbyte = i2c.readByte(ICM20689_GYRO_YOUT_H);
	uint8_t lowbyte  = i2c.readByte(ICM20689_GYRO_YOUT_L);
	int16_t gyro_yout = highbyte <<8 | lowbyte;

	return (float)(gyro_yout-gyroOffset.y)/131;
}

float LittleBird_ICM20689::getGyroZ()
{
	uint8_t highbyte = i2c.readByte(ICM20689_GYRO_ZOUT_H);
	uint8_t lowbyte  = i2c.readByte(ICM20689_GYRO_ZOUT_L);
	int16_t gyro_zout = highbyte <<8 | lowbyte;
	
	return (float)(gyro_zout-gyroOffset.z)/131;
}

float LittleBird_ICM20689::getAccelX()
{
	uint8_t highbyte = i2c.readByte(ICM20689_ACCEL_XOUT_H);
	uint8_t lowbyte  = i2c.readByte(ICM20689_ACCEL_XOUT_L);
	int16_t accel_xout = highbyte <<8 | lowbyte;
	
	return (float)(accel_xout-accelOffset.x)/16384;
}

float LittleBird_ICM20689::getAccelY()
{
	uint8_t highbyte = i2c.readByte(ICM20689_ACCEL_YOUT_H);
	uint8_t lowbyte  = i2c.readByte(ICM20689_ACCEL_YOUT_L);
	int16_t accel_yout = highbyte <<8 | lowbyte;
	
	return (float)(accel_yout-accelOffset.y)/16384;
}

float LittleBird_ICM20689::getAccelZ()
{
	uint8_t highbyte = i2c.readByte(ICM20689_ACCEL_ZOUT_H);
	uint8_t lowbyte  = i2c.readByte(ICM20689_ACCEL_ZOUT_L);
	int16_t accel_zout = highbyte <<8 | lowbyte;
	
	return (float)(accel_zout-accelOffset.z)/16384;
}

uint8_t LittleBird_ICM20689::getPowerManagement1()
{
	return i2c.readByte(ICM20689_PWR_MGMT_1);
}

uint8_t LittleBird_ICM20689::setPowerManagement1(uint8_t powermgt)
{
	i2c.writeByte(ICM20689_PWR_MGMT_1, powermgt);
	return i2c.readByte(ICM20689_PWR_MGMT_1);
}

void LittleBird_ICM20689::setClockSource(uint8_t clksel)
{
	uint8_t powermgt=getPowerManagement1();
	powermgt &= 0xF8;
	powermgt |= clksel;
	powermgt=setPowerManagement1(powermgt);
}

void LittleBird_ICM20689::setSleep(bool sleep) 
{
	uint8_t powermgt = getPowerManagement1();
	if (sleep) {
		powermgt |= (1<<ICM20689_SLEEP_BIT);		// set bit to 1 for sleep
	} else {
		powermgt &= ~(1<<ICM20689_SLEEP_BIT);		// set bit to 0 for wake up
	}

	i2c.writeByte(ICM20689_PWR_MGMT_1, powermgt);
}

bool LittleBird_ICM20689::isShaked(uint16_t shakePeriod)
{
	rawdata raw;
	getRAWAccel(&raw);
	long current = millis();
	bool shaked=false;
	
	while ((millis()-current) < shakePeriod) {
		if ((abs(raw.x)>31000) || (abs(raw.x)>31000) || (abs(raw.x)>31000))
		{
			shaked=true;
		}
		else
		{
			shaked=false;
			break;
		}
	}
	return shaked;
}

