/*************************************************** 
This is a library for the LittleBird Standard I2C library

Designed specifically to work with the LittleBird Shakey
----> https://www.littlebirdelectronics.com.au/shakey


LittleBird invests time and resources providing this open source code, 
please support LittleBird and open-source hardware by purchasing 
products from LittleBird Electronics!

Written by JP Liew for Little Bird Electronics
BSD license, all text above must be included in any redistribution
****************************************************/

#ifndef LITTLEBIRD_I2C_H
#define LITTLEBIRD_I2C_H

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif


class LittleBird_I2C
{
	uint8_t	_i2cAddress;

public:
	LittleBird_I2C();
	
	void begin();
	void end();
	uint8_t getAddress();
	void setAddress(uint8_t i2cAddress);
	uint8_t readByte(uint8_t regAddr);
	uint8_t readBytes(uint8_t regAddr, uint8_t *data, uint8_t length);
	bool writeByte(uint8_t regAddr, uint8_t data);
	bool writeBytes(uint8_t regAddr, uint8_t *data, uint8_t length);
};
#endif